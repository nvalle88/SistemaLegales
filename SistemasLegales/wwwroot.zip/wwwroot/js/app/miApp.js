﻿var MiApp = function () {
    return {
        init: function () {

        }
    }
}();